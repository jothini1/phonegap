/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package essentials;

/**
 *
 * @author tommy
 */
public class Essentials {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fenster f=new Fenster();
        f.setVisible(true);
    }
}

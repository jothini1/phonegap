/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bildmanipulator;

/**
 *
 * @author tommy
 */
public class BildManipulator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fenster f=new Fenster();
        f.setVisible(true);
    }
}
